document.addEventListener("DOMContentLoaded", () => {
    const botó = document.getElementById("marcar-btn");
    const formulari = document.getElementById("formulari");
    const confirmar = document.getElementById("confirmar-btn");

    const ofSelect = document.getElementById("of-select");
    const ofAltres = document.getElementById("of-altre");

    const llocSelect = document.getElementById("lloc-select");
    const llocAltres = document.getElementById("lloc-altre");

    const comentaris = document.getElementById("comentaris");

    let mode = botó.textContent.includes("ENTRADA") ? "ENTRADA" : "SORTIDA";

    const actualitzaBotó = () => {
        fetch("/")
            .then(res => res.text())
            .then(html => {
                const estat = html.includes("SORTIDA") ? "ENTRADA" : "SORTIDA";
                mode = estat;
                botó.textContent = "MARCAR " + estat;
                botó.className = estat === "ENTRADA" ? "entrada" : "sortida";
            });
    };

    actualitzaBotó();

    botó.addEventListener("click", () => {
        if (mode === "ENTRADA") {
            formulari.style.display = "block";
            botó.style.display = "none";
        } else {
            fetch("/marcar", {
                method: "POST",
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ tipus: "SORTIDA" })
            }).then(() => location.reload());
        }
    });

    confirmar.addEventListener("click", () => {
        const ofVal = ofSelect.value === "altre" ? ofAltres.value : ofSelect.value;
        const llocVal = llocSelect.value === "altre" ? llocAltres.value : llocSelect.value;

        fetch("/marcar", {
            method: "POST",
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                tipus: "ENTRADA",
                of: ofVal,
                lloc: llocVal,
                comentaris: comentaris.value
            })
        }).then(() => location.reload());
    });

    ofSelect.addEventListener("change", () => {
        ofAltres.style.display = ofSelect.value === "altre" ? "inline-block" : "none";
    });

    llocSelect.addEventListener("change", () => {
        llocAltres.style.display = llocSelect.value === "altre" ? "inline-block" : "none";
    });
});